<?php $__env->startSection('content'); ?>
    <div class="row">
        <h3>selamat datang di sisfo pegawai</h3>
        <!-- Earnings (Monthly) Card Example -->
    </div>

    <!-- Content Row -->

    <div class="row">

        <!-- Area Chart -->

    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Content Column -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fauzy/Documents/belajar coding/laravelSession/tugasCrudUlang/resources/views/dashboard.blade.php ENDPATH**/ ?>