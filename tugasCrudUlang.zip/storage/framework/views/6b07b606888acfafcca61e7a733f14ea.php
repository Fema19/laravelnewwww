<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Sisfo pegawai created by Fauzy </span>
        </div>
    </div>
</footer>
<?php /**PATH /home/fauzy/Documents/belajar coding/laravelSession/tugasCrudUlang/resources/views/layouts/footer.blade.php ENDPATH**/ ?>