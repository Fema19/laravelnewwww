<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('departemen.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6>Formulir Tambah departemen</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Nama Departemen</label>
                            <input type="text" class="form-control" name="nama_departemen"
                                value="<?php echo e(old('nama_departemen')); ?>">
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fauzy/Documents/belajar coding/laravelSession/tugasCrudUlang/resources/views/departemen/create.blade.php ENDPATH**/ ?>