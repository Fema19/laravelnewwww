# Laravel Crud



### tech stack used in this project
- laravel 10.0
- bootsrap 5.0

## preview/run

To Preview this project run

```bash
  php artisan serve
```
